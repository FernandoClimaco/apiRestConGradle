package com.sv.registros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestConGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
