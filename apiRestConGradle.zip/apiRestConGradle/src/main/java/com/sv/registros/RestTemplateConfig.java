package com.sv.registros;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {
	
	
	/* Este es un Bean, donde refleja mi metodo de tipo RestTemplate que retorna la instancia RestTemplate
      donde se me guarda en el contenedor gracias a la anotacion @Bean  */
	
	@Bean("clienteRest")
	public RestTemplate registrarRestTemplate() {
		return new RestTemplate();
	}
	
	
	

}
