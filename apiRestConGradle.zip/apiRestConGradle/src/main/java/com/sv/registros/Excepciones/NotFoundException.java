package com.sv.registros.Excepciones;

public class NotFoundException extends Exception {

	 
	 
	private static final long serialVersionUID = 1L;

	public NotFoundException(String mensaje) {
		super(mensaje);
	}
	
	
}
