package com.sv.registros.util;

import org.springframework.http.HttpHeaders;

public class CustomException extends RuntimeException  {

	 
	private static final long serialVersionUID = 1L;
    private final String cod;                                // variable final.
	
     
    // creacion de  2 constructores:
    public CustomException(String codigo , String mensaje){
		super(mensaje);
		this.cod = codigo;
	}
	
	
    public CustomException(String mensaje){
		super(mensaje); 
		this.cod = "";
	}


    // get de codigo:
	public String getCod() {
		return cod;
	}
    
    
    
	
	
}
