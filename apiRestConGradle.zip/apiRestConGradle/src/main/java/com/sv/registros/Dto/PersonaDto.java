package com.sv.registros.Dto;

import java.io.Serializable;

public class PersonaDto implements Serializable {

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

	// Declaracion variables
	private Integer id;

	private String nombre;
	
	private String apellidos;
	
	private int edad;
	
	private int paisId;
	
	private int estadoId;
	
	private double sueldo;
	
	//get y set


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public int getPaisId() {
		return paisId;
	}

	public void setPaisId(int paisId) {
		this.paisId = paisId;
	}

	public int getEstadoId() {
		return estadoId;
	}

	public void setEstadoId(int estadoId) {
		this.estadoId = estadoId;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	
	
	
	
	
}
