package com.sv.registros.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.sv.registros.AppConstants; 
import com.sv.registros.Dto.PersonaDto;
import com.sv.registros.Dto.PersonaDtoMejorada;
import com.sv.registros.Excepciones.APIException;
import com.sv.registros.Excepciones.NotFoundException;
import com.sv.registros.modelo.Estado;
import com.sv.registros.modelo.Pais;
import com.sv.registros.modelo.Persona;
import com.sv.registros.modelo.Planillas;
import com.sv.registros.repository.PersonaRepository;
import com.sv.registros.repository.repo.PersonaRepo;
import com.sv.registros.util.CustomException;

@Service
@Transactional
public class PersonaService {

	
	// Instanciando Logger
	private static final Logger logger = LoggerFactory.getLogger(PersonaRepo.class);

	
	// Inyectamos el con el fin de obtener las propiedades. Environment
	@Autowired
	private Environment env; 

	//Instanciando clase PersonaRepo.
	@Autowired
	PersonaRepo personaRepo;
	
	
	//Inyectando mi RestTemplate:
	@Autowired
	private RestTemplate clienteRest;


	

	// --METODOS CRUD--
	
	
	// 1. mostrar todo:
	public List<Persona> findAll() {
		return personaRepo.findAll();
	}

	
	
	// 2.METODO GUARDAR
	public void guardarPersonaDto(PersonaDto personaDto) {

		try {
			Persona p = new Persona();
			p.setId(personaDto.getId());
			p.setNombre(personaDto.getNombre());
			p.setApellidos(personaDto.getApellidos());
			p.setEdad(personaDto.getEdad());

			// instanciando mi clase Pais
			Pais pais = new Pais();
			pais.setId(personaDto.getPaisId());

			p.setPaisId(pais);

			// instanciando mi clase Estado
			Estado estado = new Estado();
			estado.setId(personaDto.getEstadoId());

			p.setEstadoId(estado);

			// VALIDACIONES:
			if (p.getNombre().equals(" ") || p.getNombre().isEmpty()) {
				throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.codigoErrorConflictoGuardar) + ", ingresar nombre");
			}
			if (p.getApellidos().equals("") || p.getApellidos().isEmpty()) {
				throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.codigoErrorConflictoGuardar) + ", ingresar apellidos");
			}
			if (p.getEdad() < 0) {
				throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.codigoErrorConflictoGuardar) + ", Edad mayor a 0 ");
			}
			if (p.getPaisId().getId() < 0) {
				throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.codigoErrorConflictoGuardar)
								+ ", El  ID pais debe ser mayor a 0 ");
			}
			if (p.getEstadoId().getId() < 0) {
				throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.codigoErrorConflictoGuardar)
								+ ", el ID estado debe ser mayor a 0 ");
			}

			
			
			personaRepo.guardar(p);   // metodo para guardar persona
			
			
			
			
			// Integrando con RestTemplate:
			// instanciando la clase planilla
			Planillas planillas = new Planillas();  
			//Setiando los valores:
			planillas.setId(personaDto.getId());
			planillas.setNombre(personaDto.getNombre());
			planillas.setApellidos(personaDto.getApellidos());
			planillas.setSalario(personaDto.getSueldo());
			
			String url = "http://localhost:2021/planillas/guardarPlanilla/";
			clienteRest.postForEntity(url, planillas, Planillas.class);

		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {
			// Haciendo uso de Logger
			logger.error("Datos no guardados");
			throw new CustomException(env.getProperty(AppConstants.codigoError),
					env.getProperty(AppConstants.mensajeError));

		}

	}

	
	
	// 3. Guardar una lista de datos:
	public String guardarLPersona(List<PersonaDto> personaDto) {

		// 1. creando un arreglo de persona para pasarle los datos de la lista
		// PersonaDto:
		List<Persona> listaPersona = new ArrayList<>();

		// 2. bucle forEach para recorrer la lista de la clase PersonaDto:
		for (PersonaDto i : personaDto) {

			Persona p = new Persona(); // instancia de mi clase persona.

			p.setId(i.getId());
			p.setNombre(i.getNombre());
			p.setApellidos(i.getApellidos());
			p.setEdad(i.getEdad());

			// instanciando mi clase Pais
			Pais pais = new Pais();
			pais.setId(i.getPaisId());
			p.setPaisId(pais);

			// Instanciando mi clase Estado
			Estado estado = new Estado();
			estado.setId(i.getEstadoId());
			p.setEstadoId(estado);

			listaPersona.add(p);

		}
		return personaRepo.guardarLPersona(listaPersona);
	} // fin del metodo guardar una lista de Personas.

	
	
	
	
	
	//4. Consulta personalizada buscar por nombre: 
	public Persona findByName(String nombre) {

		Persona p = personaRepo.findByName(nombre);

		try {

			if (p == null) {
				throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						String.format(env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado), p.getNombre()));
			}
		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {

			env.getProperty("mensaje.error");

			// Haciendo uso de Logger
			logger.error("No se encontro el registro" + exc);
			throw new CustomException(env.getProperty(AppConstants.codigoNoEncontrado),
					env.getProperty(AppConstants.mensajeNoEncontrado));
		}
		return p;
	} // fin del metodo buscar por nombre

	
	
	
	
	// 1.1 consulta personalizada un join con las dos tablas relacionales
	public PersonaDtoMejorada consultaPerMejorada(int id) {

		PersonaDtoMejorada persona = new PersonaDtoMejorada();

		try {
			// p = personaRepository.findByIdQ(id);

			persona = personaRepo.findByIdPersonaDtoMejorada(id);

			if (persona == null) {
				throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
			}
		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {
			// Haciendo uso de Logger
			logger.error("No se encontro el registro");
			throw new CustomException(env.getProperty(AppConstants.codigoNoEncontrado),
					env.getProperty(AppConstants.mensajeNoEncontrado));
		} 
		return persona;
	}

	
	
	
	// buscar por id atraves de mi consulta personalizada.
	public Persona findByIdPer(int id) {

		Persona p = null;

		try {
			p = personaRepo.findByIdPersona(id);

			if (p == null) {
				throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
			} 
		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {
			// Haciendo uso de Logger
			logger.error("No se encontro el registro" + exc);
			throw new CustomException(env.getProperty(AppConstants.codigoNoEncontrado),
					env.getProperty(AppConstants.mensajeNoEncontrado));
		} 
		return p;
	}

	
	
	
	
	// obtener id por Optional
	public Optional<Persona> obtenerPorId(int id){
		Optional<Persona> p = null;
		  
		try {
			p = personaRepo.obtenerPorId(id);

			if (p.isEmpty()) {
				throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
			}

		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {
			// Haciendo uso de Logger
			  logger.error("No se encontro el registro" + exc);
			  throw new CustomException(env.getProperty(AppConstants.codigoNoEncontrado),
								env.getProperty(AppConstants.mensajeNoEncontrado));
		}

		return p; 
	}
	
	

	
	// Editando por el metodo guardar.
	public void editar(PersonaDto personaDto) {

		try {

			// 1. Setiando la clase persona, los valores a pasarle son de la clase
			// PersonaDto:
			Persona p = new Persona();
			p.setId(personaDto.getId());
			p.setNombre(personaDto.getNombre());
			p.setApellidos(personaDto.getApellidos());
			p.setEdad(personaDto.getEdad());

			// instanciando mi clase Pais
			Pais pais = new Pais();
			pais.setId(personaDto.getPaisId());
			p.setPaisId(pais); // pasandole el objeto pais.

			// instanciando mi clase Estado
			Estado estado = new Estado();
			estado.setId(personaDto.getEstadoId());
			p.setEstadoId(estado); // pasandole el objeto estado.

			// 2. Buscar por medio del ID
			Persona pp = personaRepo.findByIdPersona(p.getId()); // utilizando el metodo: buscar por ID.

			if (pp != null) {
				// Respectivas validaciones:

				if (p.getNombre() != null && !p.getNombre().equals("") && !p.getNombre().isEmpty()) {
					pp.setNombre(p.getNombre());
				}
				if (p.getApellidos() != null && !p.getApellidos().equals("") && !p.getApellidos().isEmpty()) {
					pp.setApellidos(p.getApellidos());
				}
				if (p.getEdad() > 0) {
					pp.setEdad(p.getEdad());
				}
				if (p.getEdad() < 0) {
					throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
							env.getProperty(AppConstants.mensajeErrorConflictoEditar) + ", La edad debe ser mayor a 0");
				}
				if (p.getPaisId().getId() >= 1) {
					pp.setPaisId(p.getPaisId());
				}
				if (p.getEstadoId().getId() >= 1) {
					pp.setEstadoId(p.getEstadoId());
				}

				personaRepo.editar(pp); // Instanciando el metodo guardar(va editar).

			} else {
				throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						String.format(env.getProperty(AppConstants.mensajeErrorConflictoEditar), p.getId()));
			}

		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {
			throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
					env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
		}

	}

	
	
	// Editando por @Modifying
	public void editarPersona(int id, String nombre, int edad) {

		// colocarle el metodo buscar por id

		try {
			PersonaDto pDto = new PersonaDto();

			Persona p = new Persona();
			p.setId(id);
			p.setNombre(nombre);
			p.setApellidos(pDto.getApellidos());
			p.setEdad(edad);

			// instanciando mi clase Pais
			Pais pais = new Pais();
			pais.setId(pDto.getPaisId());

			p.setPaisId(pais);

			// instanciando mi clase Estado
			Estado estado = new Estado();
			estado.setId(pDto.getEstadoId());

			p.setEstadoId(estado);

			personaRepo.editarPersona(p);

		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {
			// Haciendo uso de Logger
			logger.error("No se encontro el registro" + exc);
			throw new CustomException("409", "Error en el servicio Buscar Persona");
		}

	}
	
	

	// ELIMINAR
	public int eliminar(Integer id) {
		int flag = 0;
		try {

			if (flag == 1) {
				personaRepo.eliminar(id);
				flag = 1;
			} else {
				throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						String.format(env.getProperty(AppConstants.mensajeErrorNoEncontrado), id));
			}

		} catch (CustomException a) {
			throw a;
		} catch (Exception exc) {
			// Haciendo uso de Logger
			logger.error("No se encontro el registro" + exc);
			throw new CustomException(env.getProperty(AppConstants.mensajeError),
					env.getProperty(AppConstants.mensajeNoEncontrado));
		}
		return flag;
	}
	
	

}
