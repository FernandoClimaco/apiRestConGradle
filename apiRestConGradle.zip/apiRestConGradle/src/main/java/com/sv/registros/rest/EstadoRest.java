package com.sv.registros.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sv.registros.modelo.Estado;
import com.sv.registros.modelo.Persona;
import com.sv.registros.service.EstadoService;

import java.net.URI;
import java.util.List;


@RestController
@RequestMapping("/estados/")
public class EstadoRest {
	
	@Autowired 
	EstadoService estadoService;
	
	
	@GetMapping("{id}")
	private  ResponseEntity<List<Estado>> getAllEstadoByPais(@PathVariable("id") int idPais){
		return ResponseEntity.ok(estadoService.findAllByCountry(idPais));
	}
	
	
	@PostMapping
	private ResponseEntity<Estado> saveEstado(@RequestBody Estado estado){
		
		try {
			Estado estadoGuardado = estadoService.save(estado);
			
			if(estadoGuardado!=null) {
				//return ResponseEntity.created(new URI("/estados/" + estadoGuardado.getId())).body(estadoGuardado);
				
				throw new Exception("datos guardados");
			}else {
				throw new Exception("datos no guardados");
			}
		}catch(Exception exc) {
			exc.printStackTrace();
			//return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			 
		}
		return null; 
	}
	
	
	

}
