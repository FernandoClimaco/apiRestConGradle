package com.sv.registros.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

 

@Entity
@Table(name="estado")
public class Estado implements Serializable{
	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="nombre")
	private String nombre;
	
	
	@ManyToOne
	@JoinColumn(name="paisid")
	private Pais pais;
	
	

	
	public Estado() {
		 
	}
	
	public Estado(int id, String nombre, Pais pais) {
		super();
		this.id = id; 
		this.nombre = nombre;
		this.pais = pais;
	}

	
	
	// get y set
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Pais getPais() {
		return pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}
