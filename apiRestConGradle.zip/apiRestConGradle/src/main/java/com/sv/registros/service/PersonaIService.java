package com.sv.registros.service;

import java.util.List;
import java.util.Optional; 
import com.sv.registros.Excepciones.APIException;
import com.sv.registros.modelo.Persona;


public interface PersonaIService {
	
	public List<Persona> findAll() throws APIException;
	public void guardar(Persona p) throws APIException;
	public String guardarLPersona(List<Persona> listaPersona);              // guardar una lista de datos
	public void editar(Persona p) throws APIException;
	public void editarPersona(Persona p) throws APIException;               // el nuevo metodo recien incorpado ocupando @Modifying
	public int eliminar(Integer id) throws APIException;                  
    public Persona findByIdPersona(int id)throws APIException;             //Consultas personalizadas.
    public Persona findByName(String nombre) throws APIException;          //Consultas personalizadas.
	public Optional<Persona> obtenerPorId(int id) throws APIException;      //Buscar por ID
   

}
