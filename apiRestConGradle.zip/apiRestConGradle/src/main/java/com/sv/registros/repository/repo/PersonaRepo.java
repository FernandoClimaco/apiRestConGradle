package com.sv.registros.repository.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.sv.registros.AppConstants;
import com.sv.registros.Dto.PersonaDto;
import com.sv.registros.Dto.PersonaDtoMejorada;
import com.sv.registros.Excepciones.APIException;
import com.sv.registros.Excepciones.NotFoundException;
import com.sv.registros.modelo.Persona;
import com.sv.registros.repository.PersonaRepository;
import com.sv.registros.service.PersonaIService;
import com.sv.registros.util.CustomException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 


@Component
public class PersonaRepo implements PersonaIService {

	// validaciones de metodos, para saber si el error viene de la bd o del desarrollador.
	
	//Instanciando Logger
	private static final Logger logger=LoggerFactory.getLogger(PersonaRepo.class);
	
	
	@Autowired 
	PersonaRepository personaRepository;
	
	@Autowired
	private Environment env; // Inyectamos el con el fin de obtener las propiedades. Environment

	
	
	
	
	@Override
	public List<Persona> findAll() { 
		List<Persona> lista = new ArrayList();
		try{ 
			  lista = personaRepository.findAll();
		}catch(Exception e){
			 e.printStackTrace();
			// Haciendo uso de Logger
			 logger.error("ERROR EN LA BASE DE DATOS");  
			 throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
			  
		}
	 return lista;
	}
	
	
	
	
	@Override
	public void guardar(Persona p){
		try{ 
		      personaRepository.save(p); 
		}catch(Exception e){
			 e.printStackTrace(); 
			 // Haciendo uso de Logger
			 logger.error("ERROR EN LA BASE DE DATOS");
			 throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.codigoErrorConflictoGuardar));
			   
		} 
		
	}
	
	
	
	
	public String guardarLPersona(List<Persona> listaPersona) { 
	   	     List<Persona> personaG = new ArrayList<>();
		       personaRepository.saveAll(listaPersona).forEach(personaG::add);
			   return "Persona guardada" + personaG.stream().map(u->u.getId()).collect((Collectors.toList() ));
  	}
	

	
	


	@Override
	public void editar(Persona p) {
		try{ 
		      personaRepository.save(p); 
		}catch(Exception e){
			 e.printStackTrace(); 
			 // Haciendo uso de Logger
			 logger.error("ERROR EN LA BASE DE DATOS");
			 throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.mensajeErrorConflictoEditar));
		} 
		
	}
	

	   // para modificar con @Modifying
	@Override
	public void editarPersona(Persona p) throws APIException {
		try{ 
		      personaRepository.updatePersonaNameAge(p.getId(), p.getNombre(), p.getEdad());
		}catch(Exception e){
			  e.printStackTrace(); 
			  // Haciendo uso de Logger
				 logger.error(" ERROR EN LA BASE DE DATOS");
			     throw new CustomException("409","Error en la base de datos, no se editaron los datos que acabas de ingresar " + e.getMessage() );
			
		} 
		
	}
	
	

	@Override
	public int eliminar(Integer id) { 
		int flag = 0;
		try{  
			
			if(flag ==1) {
				 personaRepository.deleteById(id);
				 flag= 1;
			}else {
				throw new CustomException("409","Datos no eliminados, no existe el ID");
			}
			
		}
			catch(CustomException e){ 
				  throw new CustomException("409","No se Eliminaron los datos " + e.getMessage() );  
			} catch(Exception e){
			  e.printStackTrace(); 
			  // Haciendo uso de Logger
			  logger.error("HAY UN ERROR EN LA BASE DE DATOS");
			  throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.mensajeErrorConflictoEliminar));
			
		} 
		return flag;
	}

	
	
	@Override
	public Persona findByIdPersona(int id)  {
		Persona p = null;
		try{ 
			p=personaRepository.findByIdQ(id);  //Consulta personalizada.
		}catch(Exception e){
			 e.printStackTrace(); 
			// Haciendo uso de Logger
		    logger.error("HAY UN ERROR EN LA BASE DE DATOS");
		    throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
					env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
			 
		} 
		return p;
	}

	
	
	// Metodo para buscar por id , haciendo uso de Optional
	@Override
	public Optional<Persona> obtenerPorId(int id){
		 Optional<Persona> p = null;
		 try {
			  p = personaRepository.findById(id);
			   
		 }catch(Exception e) {
			 e.printStackTrace();
			 logger.error("Error en la base de datos");
			 throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
		 }
		return p;
	}
	
	
	
	
	// metodo para personaMejorada   06/junio/2021
	public PersonaDtoMejorada findByIdPersonaDtoMejorada(int id)  {
		PersonaDtoMejorada p = null;
		try{ 
			p=personaRepository.consultaTresTablas(id);
		}catch(Exception e){
			 e.printStackTrace(); 
			// Haciendo uso de Logger
		    logger.error("HAY UN ERROR EN LA BASE DE DATOS");
		    throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
					env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado)); 
			 
		} 
		return p;
	}
	

	
	
	@Override
	public Persona findByName(String nombre){
		Persona p = null;
		try{ 
			p=personaRepository.findByName(nombre);
		}catch(Exception e){
			 e.printStackTrace(); 
			 // Haciendo uso de Logger
			 logger.error("HAY UN ERROR EN LA BASE DE DATOS");
			 throw new CustomException(env.getProperty(AppConstants.mensajeErrorNoEncontrado),
						env.getProperty(AppConstants.mensajeErrorConflictoNoEncontrado));
			
		} 
		return p;
	}


	




	


	
	 
	
	
	
	
	

}
