package com.sv.registros.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sv.registros.Dto.PersonaDto;
import com.sv.registros.Dto.PersonaDtoMejorada;
import com.sv.registros.Excepciones.APIException;
import com.sv.registros.Excepciones.NotFoundException;
import com.sv.registros.modelo.Persona;

 

public interface PersonaRepository extends JpaRepository<Persona, Integer> {
	
	
    // para modificar:
	@Modifying
	@Query("update Persona p  set p.nombre=:nombre,  edad=:edad where p.id=:id")
	void updatePersonaNameAge(@Param("id") Integer id,  @Param("nombre") String nombre , @Param("edad") int edad);
	
	
	
	
	/*
	 // mi consulta personalizada   04/JUNIO/2021
		@Query("select p.id, p.nombre,p.apellidos, p.edad ,p.paisId.nombre, p.estadoId.nombre from  Persona p where p.id = ?1 ")
		public Object[] consultaTresTablas(int id);
	*/
	
	
	
	
	// mi consulta personalizada   04/JUNIO/2021
			@Query("select new com.sv.registros.Dto.PersonaDtoMejorada(p.id, p.nombre,p.apellidos, p.edad ,p.paisId.nombre, p.estadoId.nombre) from  Persona p where p.id = ?1 ")
			public PersonaDtoMejorada consultaTresTablas(int id);
		
		
			
			
		
	/*
			 @Query(value = "select * from persona", nativeQuery = true)
			 Collection<Persona> findAllActiveUsersNative();
    */
	
		
  
	    // buscar por nombre 
		@Query("select p  from Persona p where p.nombre = ?1")
		 Persona findByNameA(String nombre) throws NotFoundException;
		
		
		
		// buscar por nombre 
				@Query("select p  from Persona p where p.nombre = ?1")
				 Persona findByName(String nombre) throws APIException;
		
		 
		
		// buscar por ID
		@Query("select p  from Persona p where p.id = ?1")
		 Persona findByIdQ(int id) throws APIException;

			


	 


		 
		

}
