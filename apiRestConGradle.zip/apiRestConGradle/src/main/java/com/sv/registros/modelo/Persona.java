package com.sv.registros.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="persona")

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Persona implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column
	private String nombre;
	
	@Column
	private String apellidos;
	
	@Column
	private int edad;
	
	@ManyToOne
	@JoinColumn(name="paisid")
	private Pais paisId;
 
	@ManyToOne
	@JoinColumn(name="estadoid")
	private Estado estadoId;

	 
	public Persona() {
		 
	}
	


	public Persona(Integer id, String nombre, String apellidos, int edad, Pais paisId, Estado estadoId) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.edad = edad;
		this.paisId = paisId;
		this.estadoId = estadoId;
	}

 

	// get y set
	
	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public String getApellidos() {
		return apellidos;
	}



	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}



	public int getEdad() {
		return edad;
	}



	public void setEdad(int edad) {
		this.edad = edad;
	}



	public Pais getPaisId() {
		return paisId;
	}



	public void setPaisId(Pais paisId) {
		this.paisId = paisId;
	}



	public Estado getEstadoId() {
		return estadoId;
	}



	public void setEstadoId(Estado estadoId) {
		this.estadoId = estadoId;
	}



	
 
	
	
}
