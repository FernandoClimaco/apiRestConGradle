package com.sv.registros.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sv.registros.modelo.Pais;

 

public interface PaisRepository extends JpaRepository<Pais, Long> {

}
