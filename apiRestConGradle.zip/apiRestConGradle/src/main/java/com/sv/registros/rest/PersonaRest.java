package com.sv.registros.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.sv.registros.Dto.PersonaDto;
import com.sv.registros.Dto.PersonaDtoMejorada;
import com.sv.registros.Excepciones.APIException;
import com.sv.registros.Excepciones.NotFoundException;
import com.sv.registros.modelo.Persona;
import com.sv.registros.repository.PersonaRepository;
import com.sv.registros.service.PersonaService;
import com.sv.registros.util.CustomException;
import com.sv.registros.util.RestResponse;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;


@RestController
@RequestMapping("/persona/")
public class PersonaRest {

	@Autowired
	PersonaService personaService; 
	
	@Autowired
	RestResponse restResponse;
	
	@Autowired
	PersonaRepository personaRepository;
	
	
	
	// 1.para listar todo:
	@GetMapping
	private ResponseEntity<List<Persona>> getAllPersona()    {
		
		ResponseEntity<List<Persona>> respuesta = null;
		
		try {
			List<Persona> listap =  personaService.findAll(); 
			 respuesta = restResponse.createCustomizedResponse(listap, 200,"0", "Success" );
			 
		}catch(CustomException a) {
			respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
			
			 
		}catch(Exception exc) {
			respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" );  
		}
	  return respuesta;  
	}
	
	
	 
	
	 
  
	// Guardar
	@PostMapping
	public ResponseEntity<?> guardarPersonas(@RequestBody PersonaDto personaDto) {
		
		ResponseEntity<?> respuesta = null;
		
		try {
			  personaService.guardarPersonaDto(personaDto); 
			 respuesta = restResponse.createCustomizedResponse(null, 200,"0", "Success" );
			 
		}catch(CustomException a) {
			respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
			
			 
		}catch(Exception exc) {
			respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" );  
		}
	  return respuesta; 
	}
	
	
	
	 // Guardar una lista
	 @PostMapping("/g")
	 public String guardarListaPersona(@RequestBody List<PersonaDto> listaPersona) {
		 return personaService.guardarLPersona(listaPersona);
	 }
		  
	 
	
	 
	
	// 3.1 para buscar por nombre
	@GetMapping("api/persona/{nombre}")
	public ResponseEntity<?> obtenerNombreE(@PathVariable("nombre") String nombre){
		 
		ResponseEntity<?> respuesta = null;
		
		try {
		     Persona p = personaService.findByName(nombre);
		     
		     if(p == null) {
					throw new CustomException("Datos no encontrados");	 
				}
		            respuesta = restResponse.createCustomizedResponse(p, 200,"0", "Success" ); 
		     }catch(CustomException a) {
					respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
					 throw a;
				}catch(Exception exc) {
					respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" ); 
				}
			  return respuesta; 
  
	}  // Fin del metodo buscar por nombre.
	
	
	
	
	
	
	
	
	// consulta mejorada: consulta hacia dos tablas
	@GetMapping("/join/{id}")
	private ResponseEntity<?> buscarTablas(@PathVariable("id") int id)   {
               ResponseEntity<?> respuesta = null;
		
		try {
		     PersonaDtoMejorada p = personaService.consultaPerMejorada(id);
		     
		     if(p == null) {
					throw new CustomException("Datos no encontrados");	 
				}
		            respuesta = restResponse.createCustomizedResponse(p, 200,"0", "Success" ); 
		     }catch(CustomException a) {
					respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
					 throw a;
				}catch(Exception exc) {
					respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" ); 
				}
			  return respuesta;  
	}
	
	
	
	
	
	
  
	// obtener por id atraves de mi consulta personalizada:
	@GetMapping("api/personaId/{id}")
	 public ResponseEntity<?> obtenerPorId(@PathVariable("id") Integer id){
		  
		ResponseEntity<?> respuesta = null;
		 
		try {
			   
			Persona p= personaService.findByIdPer(id);
			if(p==null) {
				throw new CustomException("Datos no encontrados");
			}
			 respuesta = restResponse.createCustomizedResponse(p, 200,"0", "Success" ); 
	    
       }catch(CustomException a) {
			respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
			 throw a;
		}catch(Exception exc) {
			respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" ); 
		}
	  return respuesta;  
		 
	}  
	
	
	
	 
	// obtener id atraves de Optional
	@GetMapping("optional/id/{id}")
	public ResponseEntity<?> optenerPorOptional(@PathVariable("id") Integer id){
		
		ResponseEntity<?> respuesta = null;
		 
		try {
			   
			Optional<Persona> p= personaService.obtenerPorId(id);
			if(p == null) {
				throw new CustomException("Datos no encontrados");
			}
			 respuesta = restResponse.createCustomizedResponse(p, 200,"0", "Success" ); 
	    
       }catch(CustomException a) {
			respuesta = restResponse.createCustomizedResponse(null, 404, a.getCod(), a.getMessage() );
			 throw a;
		}catch(Exception exc) {
			respuesta = restResponse.createCustomizedResponse(null, 404,"404", "Error en el servicio" ); 
		}
	  return respuesta;  
	}
	 
	
	
	  
	
	// 4. Editar por medio del metodo guardar 
			@PutMapping("api/personaeditar")
			public ResponseEntity<?> editar(@RequestBody PersonaDto personaDto){
				
				ResponseEntity<?> respuesta = null;
				
				try {
					personaService.editar(personaDto);
					respuesta = restResponse.createCustomizedResponse(null, 200,"0", "Success" );
					 
				}catch(CustomException a) {
					respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
					 
				}catch(Exception exc) {
					respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" ); 
				}
			  return respuesta;  
			}
			
			
			
			// 4. Editar por @Modifying
						@PutMapping("api/editarPersona")
						public ResponseEntity<?> editarPersona(@RequestBody PersonaDto pDto){
							
							ResponseEntity<?> respuesta = null;
							
							try {
								personaService.editarPersona(pDto.getId(), pDto.getNombre() ,  pDto.getEdad());
								respuesta = restResponse.createCustomizedResponse(null, 200,"0", "Success" );
								 
							}catch(CustomException a) {
								respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
								 
							}catch(Exception exc) {
								respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" ); 
							}
						  return respuesta;  
						}
	 
	
	
	
	
 
	// Eliminar
	@DeleteMapping("api/persona/{id}")
	public ResponseEntity<?> eliminar(@PathVariable("id") Integer id){ 
		 
		 ResponseEntity<?> respuesta = null;
		 try {
		     int p = personaService.eliminar(id); 
		     
		     if(p == 0) {
					throw new CustomException("Datos no eliminados");	 
				}
		            respuesta = restResponse.createCustomizedResponse(p, 200,"0", "Success" ); 
		     }catch(CustomException a) {
					respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage() );
					 throw a;
				}catch(Exception exc) {
					respuesta = restResponse.createCustomizedResponse(null, 409,"409", "Error en el servicio" ); 
				}
			  return respuesta; 
	 }
	
	
		
		
	
}
