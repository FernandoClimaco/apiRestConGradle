package com.sv.registros.Dto;

import java.io.Serializable;

public class PersonaDtoMejorada implements Serializable {

	// Declaracion variables
		private Integer id;

		private String nombre;
		
		private String apellidos;
		
		private int edad;
		
		private String nombrePais;
		
		private String nombreEstado;
		
		
		
		
		

		public PersonaDtoMejorada() {
			super();
		}

		public PersonaDtoMejorada(Integer id, String nombre, String apellidos, int edad, String nombrePais,
				String nombreEstado) {
			super();
			this.id = id;
			this.nombre = nombre;
			this.apellidos = apellidos;
			this.edad = edad;
			this.nombrePais = nombrePais;
			this.nombreEstado = nombreEstado;
		}

		
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public String getApellidos() {
			return apellidos;
		}

		public void setApellidos(String apellidos) {
			this.apellidos = apellidos;
		}

		public int getEdad() {
			return edad;
		}

		public void setEdad(int edad) {
			this.edad = edad;
		}

		public String getNombrePais() {
			return nombrePais;
		}

		public void setNombrePais(String nombrePais) {
			this.nombrePais = nombrePais;
		}

		public String getNombreEstado() {
			return nombreEstado;
		}

		public void setNombreEstado(String nombreEstado) {
			this.nombreEstado = nombreEstado;
		}
		
		
		
		
		
		
}
